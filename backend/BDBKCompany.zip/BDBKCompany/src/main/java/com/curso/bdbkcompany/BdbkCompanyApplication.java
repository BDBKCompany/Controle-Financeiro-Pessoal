package com.curso.bdbkcompany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BdbkCompanyApplication {

    public static void main(String[] args) {
        SpringApplication.run(BdbkCompanyApplication.class, args);
    }

}
